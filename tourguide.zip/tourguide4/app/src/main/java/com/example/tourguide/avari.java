package com.example.tourguide;

import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class avari extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avari);


        ImageView i1 = (ImageView)findViewById(R.id.call_icon_image);
        i1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(Intent.ACTION_DIAL);
                i1.setData(Uri.parse("tel:(042) 36366366 "));
                if(i1.resolveActivity(getPackageManager()) != null) {
                    startActivity(i1);
                }
            }
        });

        ImageView i2 = (ImageView)findViewById(R.id.web_search_image);
        i2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String info = "http://www.avari.com";
                Intent i2 = new Intent(Intent.ACTION_WEB_SEARCH);
                i2.putExtra(SearchManager.QUERY, info);
                if (i2.resolveActivity(getPackageManager()) != null) {
                    startActivity(i2);
                }
            }
        });

        ImageView i3 = (ImageView)findViewById(R.id.google_map_search_image);
        i3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri gmmIntentUri = Uri.parse("https://www.google.com/search?q=avari+hotel+dubai&sxsrf=AOaemvIzJkuTWhwrg11Vy3a1MXXLYh1nKg%3A1633115396635&ei=BF1XYZn-JZj6wAPe94bIBg&hotel_occupancy=2&ved=0ahUKEwiZkN_49KnzAhUYPXAKHd67AWkQ4dUDCA4&uact=5&oq=avari+hotel+dubai&gs_lcp=Cgdnd3Mtd2l6EAMyEAguEMcBEK8BELADECcQkwIyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyEAguEMcBEK8BEMgDELADEEMyEAguEMcBEK8BEMgDELADEEMyEAguEMcBEK8BEMgDELADEEMyEAguEMcBEK8BEMgDELADEEMyEAguEMcBEK8BEMgDELADEEMyEAguEMcBEK8BEMgDELADEENKBQg4EgExSgQIQRgAUABYAGCxkgloAXACeACAAQCIAQCSAQCYAQDIAQ_AAQE&sclient=gws-wiz");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                if(mapIntent.resolveActivity(getPackageManager()) != null)
                {
                    startActivity(mapIntent);
                }

            }
        });

    }
}