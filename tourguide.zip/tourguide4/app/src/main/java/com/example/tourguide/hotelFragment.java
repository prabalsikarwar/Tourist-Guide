package com.example.tourguide;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class hotelFragment extends Fragment {


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

 View view2 = inflater.inflate(R.layout.activity_hotel_fragment,container,false);


        TextView t1 =(TextView)view2.findViewById(R.id.numberhotel);
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i1 = new Intent(getActivity(),avari.class);
                startActivity(i1);

            }
        });
        TextView t2 =(TextView)view2.findViewById(R.id.numberhotel2);
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i2 = new Intent(getActivity(), hotel_heritage.class);
                startActivity(i2);}

        } );

        TextView t3 = (TextView) view2.findViewById(R.id.numberhotel3);
        t3.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick (View view){

                Intent i3 = new Intent(getActivity(),hotel_nishat.class);
                startActivity(i3);
            }
        });

        TextView t4 = (TextView) view2.findViewById(R.id.numberhotel4);
        t4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i4 = new Intent(getActivity(), historical_khanjahan.class);
                startActivity(i4);
            }
        });

        TextView t5 = (TextView) view2.findViewById(R.id.numberhotel5);
        t5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i5 = new Intent(getActivity(), hotel_pc.class);
                startActivity(i5);
            }
        });

        TextView t6 = (TextView) view2.findViewById(R.id.numberhotel6);
        t6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i6 = new Intent(getActivity(), hotel_taj.class);
                startActivity(i6);
            }
        });
        TextView t7 = (TextView) view2.findViewById(R.id.numberhotel7);
        t7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i7 = new Intent(getActivity(),hotel_amar.class);
                startActivity(i7);
            }
        });

        TextView t8 = (TextView) view2.findViewById(R.id.numberhotel8);
        t8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i8 = new Intent(getActivity(), hotel_raddiso.class);
                startActivity(i8);
            }
        });

        TextView t9 = (TextView) view2.findViewById(R.id.numberhotel9);
        t9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i9 = new Intent(getActivity(), hotel_ic.class);
                startActivity(i9);
            }
        });
        TextView t10= (TextView) view2.findViewById(R.id.numberhotel10);
        t10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i10 = new Intent(getActivity(), hotel_clark.class);
                startActivity(i10);
            }
        });

        return view2;
    }
}