package com.example.tourguide;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class historical_redfort extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historical_redfort);
    }
}