package com.example.tourguide;

import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class food_biryani extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_biryani);
        ImageView i1 = (ImageView)findViewById(R.id.call_icon_image);
        i1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(Intent.ACTION_DIAL);
                i1.setData(Uri.parse("tel: 9897095770"));
                if(i1.resolveActivity(getPackageManager()) != null) {
                    startActivity(i1);
                }
            }
        });

        ImageView i2 = (ImageView)findViewById(R.id.web_search_image);
        i2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String info = "https://www.google.com/search?q=jaidi+biryani&sxsrf=AOaemvJ3GO-RyjsTgBfPBFUtioxKiNCl0Q%3A1633111210776&ei=qkxXYd3lLv3Az7sP4NCwCA&gs_ssp=eJzj4tVP1zc0TE9KKzZLMU4yYLRSNagwtjS0NDA1TDIzSk1OSTU1tjKoSDNISzROTDQ2sLBIMzAwM_TizUrMTMlUSMosqkzMywQAm-0UEQ&oq=jaidi+biryani&gs_lcp=Cgdnd3Mtd2l6EAMYADITCC4QgAQQhwIQxwEQrwEQFBCTAjIKCAAQgAQQhwIQFDIFCAAQgAQyBQgAEIAEMgUIABCABDIFCAAQgAQyBQgAEIAEOgcIIxDqAhAnOgcILhDqAhAnOgQIIxAnOgUIABCRAjoLCAAQgAQQsQMQgwE6GgguEIAEELEDEIMBEMcBENEDEIsDENIDEKgDOggIABCABBCxAzoFCC4QgAQ6BQguEJECOgQIABBDOgsILhCABBCxAxCDAToLCC4QsQMQkQIQkwI6BAguEEM6CgguELEDEEMQkwI6BwguELEDEEM6CAguEIAEEJMCOgcIABCABBAKOg4ILhCABBDHARCvARCTAjoICAAQgAQQyQM6BAgAEAo6BwguELEDEAo6BAguEAo6CggAELEDEIMBEApKBAhBGABQ8MsBWI_wAWDchAJoAXACeACAAZECiAGqEpIBBjAuMTAuM5gBAKABAbABCrgBAsABAQ&sclient=gws-wiz";
                Intent i2 = new Intent(Intent.ACTION_WEB_SEARCH);
                i2.putExtra(SearchManager.QUERY, info);
                if (i2.resolveActivity(getPackageManager()) != null) {
                    startActivity(i2);
                }
            }
        });

        ImageView i3 = (ImageView)findViewById(R.id.google_map_search_image);
        i3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri gmmIntentUri = Uri.parse("https://www.google.com/maps/place/JAIDI+Pan+Shop+%26+Biryani/@31.5343178,74.3624545,17z/data=!3m1!4b1!4m5!3m4!1s0x3919051b62ecde53:0xf0fa3aa3088f0061!8m2!3d31.5343178!4d74.3646432");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                if(mapIntent.resolveActivity(getPackageManager()) != null)
                {
                    startActivity(mapIntent);
                }

            }
        });
    }
}