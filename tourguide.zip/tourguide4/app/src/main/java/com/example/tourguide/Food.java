package com.example.tourguide;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class Food extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        View view4 = inflater.inflate(R.layout.fragment_food,container,false);



        TextView t1 =(TextView)view4.findViewById(R.id.numberfood);
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i1 = new Intent(getActivity(),food_biryani.class);
                startActivity(i1);

            }
        });
        TextView t2 =(TextView)view4.findViewById(R.id.numberfood2);
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i2 = new Intent(getActivity(), food_cahanay.class);
                startActivity(i2);}

        } );

        TextView t3 = (TextView) view4.findViewById(R.id.numberfood3);
        t3.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick (View view){

                Intent i3 = new Intent(getActivity(),food_haleem.class);
                startActivity(i3);
            }
        });

        TextView t4 = (TextView) view4.findViewById(R.id.numberfood4);
        t4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i4 = new Intent(getActivity(), food_karakhi.class);
                startActivity(i4);
            }
        });

        TextView t5 = (TextView) view4.findViewById(R.id.numberfood5);
        t5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i5 = new Intent(getActivity(), halwa.class);
                startActivity(i5);
            }
        });

        TextView t6 = (TextView) view4.findViewById(R.id.numberfood6);
        t6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i6 = new Intent(getActivity(), food_mitthi.class);
                startActivity(i6);
            }
        });
        TextView t7 = (TextView) view4.findViewById(R.id.numberfood7);
        t7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i7 = new Intent(getActivity(),food_seekh.class);
                startActivity(i7);
            }
        });







        return view4;
    }
}