package com.example.tourguide;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class historicalFragment extends Fragment{

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view1 = inflater.inflate(R.layout.activity_historical_fragment, container, false);

TextView t1 =(TextView)view1.findViewById(R.id.numberview);
t1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

        Intent i1 = new Intent(getActivity(),cypress.class);
        startActivity(i1);

    }
});
TextView t2 =(TextView)view1.findViewById(R.id.numberview2);
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i2 = new Intent(getActivity(), historical_gulabi.class);
                startActivity(i2);}

            } );

                TextView t3 = (TextView) view1.findViewById(R.id.numberview3);
                t3.setOnClickListener(new View.OnClickListener()

            {
                @Override
                public void onClick (View view){

                Intent i3 = new Intent(getActivity(), historical_haveli.class);
                startActivity(i3);
            }
            });

                        TextView t4 = (TextView) view1.findViewById(R.id.numberview4);
                        t4.setOnClickListener(new View.OnClickListener() {
                                                  @Override
                                                  public void onClick(View view) {

                                                      Intent i4 = new Intent(getActivity(), historical_khanjahan.class);
                                                      startActivity(i4);
                                                  }
                                              });

                                TextView t5 = (TextView) view1.findViewById(R.id.numberview5);
                                t5.setOnClickListener(new View.OnClickListener() {
                                                          @Override
                                                          public void onClick(View view) {

                                                              Intent i5 = new Intent(getActivity(), historical_lahore.class);
                                                              startActivity(i5);
                                                          }
                                                      });

                                        TextView t6 = (TextView) view1.findViewById(R.id.numberview6);
                                t6.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {

                                        Intent i6 = new Intent(getActivity(), historical_mariyam.class);
                                        startActivity(i6);
                                    }
                                    });
                                        TextView t7 = (TextView) view1.findViewById(R.id.numberview7);
                                        t7.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {

                                                Intent i7 = new Intent(getActivity(), historical_redfort.class);
                                                startActivity(i7);
                                            }
                                        });

                                                TextView t8 = (TextView) view1.findViewById(R.id.numberview8);
                                                t8.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View view) {
                                                        Intent i8 = new Intent(getActivity(), historical_tajmahal.class);
                                                        startActivity(i8);
                                                    }
                                                });

        TextView t9 = (TextView) view1.findViewById(R.id.numberview9);
        t9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i9 = new Intent(getActivity(), humanyutomb.class);
                startActivity(i9);
            }
        });

                                                return view1;
                                            }
                                        }