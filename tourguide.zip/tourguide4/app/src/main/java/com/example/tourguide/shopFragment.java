package com.example.tourguide;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.zip.Inflater;

public class shopFragment extends Fragment {

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
     View view3 = inflater.inflate(R.layout.activity_shop_fragment,container,false);


        TextView t1 =(TextView)view3.findViewById(R.id.numbershop);
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i1 = new Intent(getActivity(),shop_amanah.class);
                startActivity(i1);

            }
        });
        TextView t2 =(TextView)view3.findViewById(R.id.numbershop2);
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i2 = new Intent(getActivity(),shop_fortress.class);
                startActivity(i2);}

        } );

        TextView t3 = (TextView) view3.findViewById(R.id.numbershop3);
        t3.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick (View view){

                Intent i3 = new Intent(getActivity(),shop_malllahore.class);
                startActivity(i3);
            }
        });

        TextView t4 = (TextView) view3.findViewById(R.id.numbershop4);
        t4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i4 = new Intent(getActivity(), emporium.class);
                startActivity(i4);
            }
        });

        TextView t5 = (TextView) view3.findViewById(R.id.numbershop5);
        t5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i5 = new Intent(getActivity(), shop_packages.class);
                startActivity(i5);
            }
        });



        return view3;
    }
}